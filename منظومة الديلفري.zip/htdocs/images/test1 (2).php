<?php
$host = "localhost"; // اسم الخادم
$user = "root"; // اسم المستخدم لقاعدة البيانات
$password = "abeer_zakut"; // كلمة المرور لقاعدة البيانات
$db = "test"; // اسم قاعدة البيانات
session_start();
// إنشاء اتصال
$conn = new mysqli($host, $user, $password, $db);

// التحقق من الاتصال
if ($conn->connect_error) {
    die("فشل الاتصال: " . $conn->connect_error);
}

// تعيين الترميز إلى UTF-8
$conn->set_charset("utf8");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $password = $_POST["password"];
    
    // استخدام العبارات المحضرة لتجنب حقن SQL
    $stmt = $conn->prepare("SELECT * FROM admin WHERE email = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    if ($row) {
        if ($row["typeuser"] == "user") {
            echo "user";
            $_SESSION["email"]=$username;

        } elseif ($row["typeuser"] == "admin") {
          //     $stmt->bind_param("ss", $username, $password);
            $_SESSION["email"]=$username;
            echo "<center  ><h2 > hallo admin</h2></center>";
            echo "<script>alert('مرحبا بك ايها المدير سيتم تحويلك الى لوحة التحكم');</script>";
            header("REFRESH:2;URL=adminpanal.php");


        }
    } else {

        echo "<script>alert('عفواً لايمكنك الدخول الي هذة الصفحة سيتم تحويلك الى المتجر');</script>";

        echo "Invalid credentials";

        header("REFRESH:2;URL=index.php");

    }
} else 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل الدخول</title>
</head>
<body>
 <center>
    <h1>login form</h1>
    <br><br>
    <div style="background-color:grey;width:500px;">
        <br><br>
        <form action="test1.php" method="POST">
            <div>
                <label for="us">username</label>
                <input type="text" name="username" required id="us">
            </div>
            <br><br>
            <div>
                <label for="pa">password</label>
                <input type="password" name="password" required id="pa">
            </div>
            <br><br>
            <div>
                <br><br>
                <input type="submit" value="login">
                <br><br>
            </div>
        </form>
    </div>
 </center>
</body>
</html>