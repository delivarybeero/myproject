<?php
$host = "localhost"; // اسم الخادم
$user = "root"; // اسم المستخدم لقاعدة البيانات
$password = "abeer_zakut"; // كلمة المرور لقاعدة البيانات
$db = "test"; // اسم قاعدة البيانات

// إنشاء اتصال
$conn = new mysqli($host, $user, $password, $db);

// التحقق من الاتصال
if ($conn->connect_error) {
    die("فشل الاتصال: " . $conn->connect_error);
}

// تعيين الترميز إلى UTF-8
$conn->set_charset("utf8");

// التحقق من طريقة الطلب
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // الحصول على البيانات المدخلة
    $username = $_POST["username"];
    $password = $_POST["password"];

    // تحضير استعلام SQL باستخدام معلمات مستعدة
    $stmt = $conn->prepare("SELECT * FROM admin WHERE email = ? AND password = ?");
    $stmt->bind_param("ss", $username, $password);

    // تنفيذ الاستعلام
    $stmt->execute();
    $result = $stmt->get_result();

    // التحقق من النتائج
    if ($row = $result->fetch_assoc()) {
        if ($row["typeuser"] == "user") {
            echo "user";
        } elseif ($row["typeuser"] == "admin") {
            echo "admin";
        } else {
            echo "Unknown user type";
        }
    } else {
        echo "Invalid credentials.";
    }

    // إغلاق الاستعلام والاتصال
    $stmt->close();
    $conn->close();
} //else {
   // echo "This is not a POST request.";
//}
?>

<!DOCTYPE html>
<html lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نموذج تسجيل الدخول</title>
</head>
<body>
 <center>
    <h1>نموذج تسجيل الدخول</h1>
    <div style="background-color:grey;width:500px;">
        <form action="test.php" method="POST">
            <div>
                <label for="us">اسم المستخدم</label>
                <input type="text" name="username" required id="us">
            </div>
            <br><br>
            <div>
                <label for="pa">كلمة المرور</label>
                <input type="password" name="password" required id="pa">
            </div>
            <br><br>
            <div>
                <input type="submit" value="تسجيل الدخول">
            </div>
            <br><br>
        </form>
    </div>
 </center>
</body>
</html>