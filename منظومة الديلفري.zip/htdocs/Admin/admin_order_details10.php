<?php
session_start();

// التحقق من صحة الجلسة
if (!isset($_SESSION['EMAIL'])) {
    header("Location: admin.php");
    exit();
}

require_once("../include/connection.php");

// جلب إعدادات الموقع
$settings = mysqli_fetch_assoc(mysqli_query($conn, 
    "SELECT site_name, logo_path, phone_number, whatsapp 
    FROM site_settings LIMIT 1"
));

// جلب بيانات الطلب
$order_id = (int)($_GET['id'] ?? 0);
$order_result = mysqli_query($conn, 
    "SELECT * FROM orders1 WHERE order_id = $order_id"
);

if (!$order_result || mysqli_num_rows($order_result) === 0) {
    die("الطلب غير موجود");
}

$order = mysqli_fetch_assoc($order_result);

// جلب عناصر الطلب
$items_result = mysqli_query($conn, 
    "SELECT oi.*, p.name, p.image 
    FROM orders1_items oi
    LEFT JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = $order_id"
);

if (!$items_result) {
    die("خطأ في جلب بيانات المنتجات: " . mysqli_error($conn));
}

$items = mysqli_fetch_all($items_result, MYSQLI_ASSOC);

// معالجة إرسال الواتساب
if (isset($_POST['send_invoice'])) {
    $site_name = $settings['site_name'];
    $products = "";
    
    foreach ($items as $item) {
        $products .= "▪️ " . $item['name'] . " - " 
                   . $item['quantity'] . "x" 
                   . number_format($item['price'], 2) . " د.ل\n";
    }
    
    $customer_phone = preg_replace('/^0+/', '', $order['phone']);
    $whatsapp_number = "218" . $customer_phone;
    
    $message = "🛍️ *فاتورة شراء من {$site_name}*\n"
             . "📅 التاريخ: " . date('Y-m-d H:i') . "\n"
             . "📋 رقم الفاتورة: #$order_id\n\n"
             . "📦 المنتجات:\n$products\n"
             . "💰 الإجمالي: " . number_format($order['total_amount'], 2) . " د.ل\n\n"
             . "شكرًا لثقتك! ❤️\n"
             . "سيصلك طلبك خلال ٢-٣ ساعات ⏳";
    
    $encoded_message = urlencode($message);
    header("Location: https://wa.me/$whatsapp_number?text=$encoded_message");
    exit();
}

// دالة مساعدة لتنسيق رقم الواتساب
function format_whatsapp_number($phone) {
    $phone = preg_replace('/^0+/', '', $phone);
    return '218' . $phone;
}
?>

<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>فاتورة الطلب</title>
    <!-- باقي محتوى ال head -->
</head>
<body>
<head>
    <!-- ... باقي محتوى ال head ... -->
    <style>
body { font-family: 'Tahoma', sans-serif; background: #f5f5f5; margin: 0; padding: 20px; }
        .order-container { max-width: 1000px; margin: 20px auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 0 20px rgba(0,0,0,0.1); }
        body {
            font-family: 'Tahoma', Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }

        .order-container {
            max-width: 1000px;
            margin: 20px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }

        /* تنسيقات حالة الطلب */
        .order-status {
            padding: 8px 15px;
            border-radius: 20px;
            font-weight: bold;
        }

        .status-pending { background: #fff3cd; color: #856404; }
        .status-processing { background: #cce5ff; color: #004085; }
        .status-completed { background: #d4edda; color: #155724; }
        .status-cancelled { background: #f8d7da; color: #721c24; }
        .status-shipped { background: #e2e3e5; color: #383d41; }

        /* تنسيقات جدول المنتجات */
        .order-table {
            width: 100%;border-collapse: collapse; margin: 25px 0;}.order-table th { background-color: #3498db; color: white;
         padding: 12px 15px;
        }

        .product-image {
            width: 70px;
            height: 70px;
            object-fit: contain;
        }

        /* تنسيقات قسم الاتصال */
        .contact-info {
            border: 1px solid #eee;
            padding: 15px;
            border-radius: 8px;
            margin: 20px 0;
        }

        .contact-item {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 15px;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 5px;
        }

        .whatsapp-btn {
            background: #25D366;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 10px;
        }

        @media (max-width: 768px) {
            /* تنسيقات الجوال */
            .order-container {
                padding: 15px;
            }
            
            .product-image {
                width: 50px;
                height: 50px;
            }
        }
        .order-table {
    width: 100%;
    border-collapse: separate; /* تغيير من collapse إلى separate */
    border-spacing: 0;
    margin: 25px 0;
    border: 2px solid #3498db; /* إطار خارجي للجدول */
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 0 20px rgba(0,0,0,0.1);
}

.order-table th,
.order-table td {
    padding: 15px;
    text-align: center;
    border: 1px solid #dcdcdc; /* حدود داخلية واضحة */
}

.order-table th {
    background-color: #3498db;
    color: white;
    border-bottom: 3px solid #2c3e50; /* حدود أسفل سميكة للرأس */
}

.order-table tr:nth-child(even) {
    background-color: #f9f9f9;
}

.order-table tr:hover {
    background-color: #f1f1f1;
}

.total-row {
    background-color: #e8f4ff !important;
    font-weight: bold;
    border-top: 2px solid #3498db; /* حد علوي مميز للمجموع */
}
@media (max-width: 768px) {
    .order-table {
        border: 1px solid #ddd;
    }
    
    .order-table td {
        padding: 10px;
        font-size: 14px;
    }
    
    .order-table th {
        padding: 12px;
        font-size: 15px;
    }
}
.order-header {
        flex-direction: column;
        align-items: flex-start;
        gap: 10px;
    }
    .customer-info {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
        }
        .customer-info h3 {
            margin-top: 0;
            color: #2c3e50;
            border-bottom: 1px dashed #ccc;
            padding-bottom: 10px;
        }
        .info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
        }
        .info-item {
            margin-bottom: 10px;
        }
        .info-label {
            font-weight: bold;
            color: #3498db;
            display: inline-block;
            width: 120px;
        }


    
/* تنسيقات الأزرار الرئيسية */
.action-buttons {
    display: flex;
    justify-content: space-between;
    margin: 30px 0;
    gap: 20px;
}

.button-group {
    display: flex;
    gap: 15px;
    align-items: center;
}

.btn {
    padding: 12px 25px;
    border-radius: 8px;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 10px;
    transition: all 0.3s ease;
    font-weight: 600;
    font-size: 15px;
    border: 2px solid transparent;
}

/* زر العودة */
.btn-back {
    background: #6c757d;
    color: white;
    box-shadow: 0 3px 6px rgba(108, 117, 125, 0.2);
}

/* زر الطباعة */
.btn-print {
    background: #17a2b8;
    color: white;
    box-shadow: 0 3px 6px rgba(23, 162, 184, 0.2);
}

/* زر التعديل */
.btn-edit {
    background: #ffc107;
    color: #212529;
    box-shadow: 0 3px 6px rgba(255, 193, 7, 0.2);
}

/* تأثيرات التحويم */
.btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.2);
    opacity: 0.9;
}

/* تنسيقات الجوال */
@media (max-width: 768px) {
    .action-buttons {
        flex-direction: column;
        gap: 15px;
    }
    
    .button-group {
        flex-direction: column;
        width: 100%;
    }
    
    .btn {
        width: 100%;
        justify-content: center;
        padding: 15px 20px;
    }
}

/* التأكد من ظهور الأيقونات */
.fas, .fab {
    font-size: 16px;
}


/* التعديلات الخاصة بزر العودة فقط */
.btn-back {
    padding: 10px 20px; /* تقليل الحشو الداخلي */
    font-size: 14px;    /* تصغير حجم الخط */
    border-radius: 6px;  /* تقليل استدارة الزوايا */
}

/* للحفاظ على تناسق الأزرار الأخرى */
.btn-print,
.btn-edit {
    padding: 10px 20px;
    font-size: 14px;
}

/* التعديلات العامة لجميع الأزرار */
.btn {
    /* الحفاظ على الخصائص السابقة مع التعديلات الجديدة */
    padding: 10px 20px;
    font-size: 14px;
    border-radius: 6px;
}

/* تحسين التنسيق للشاشات الصغيرة */
@media (max-width: 768px) {
    .btn {
        padding: 8px 15px;
        font-size: 13px;
    }
}
action-buttons {
    display: flex;
    justify-content: space-between;
    margin-top: 30px;
    gap: 15px;
    flex-wrap: wrap;
}

.button-group {
    display: flex;
    gap: 15px;
}

.btn {
    padding: 12px 25px;
    border-radius: 8px;
    text-decoration: none;
    display: inline-flex;
    align-items: center;
    gap: 10px;
    transition: all 0.3s;
    font-weight: bold;
    border: none;
    cursor: pointer;
}

.btn-back {
    background: #6c757d;
    color: white;
}

.btn-print {
    background: #17a2b8;
    color: white;
}

.btn-edit {
    background: #ffc107;
    color: #212529;
}

.btn:hover {
    opacity: 0.9;
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

/* تنسيقات خاصة بالطباعة */
@media print {
    .action-buttons {
        display: none !important;
    }
    
    .order-container {
        box-shadow: none;
        border: 1px solid #ddd;
    }
}

/* تنسيقات الجوال */
@media (max-width: 768px) {
    .action-buttons {
        flex-direction: column;
    }
    
    .button-group {
        flex-direction: column;
        width: 100%;
    }
    
    .btn {
        justify-content: center;
        width: 100%;
    }
}
.logo {
            width: 50px;
            height: 50px;
            border-radius: 50%; /* جعل الشعار دائري */
            object-fit: cover;
            border: 2px solid var(--primary-color);
        }
        
        @media print {
    .no-print, 
    .action-buttons, 
    .contact-info { /* أضف هذه الفئة */
        display: none !important;
    }
    
    .order-container {
        box-shadow: none;
        border: 1px solid #ddd;
    }
}

        
        /* ... باقي التنسيقات ... */



        /* التعديلات الجديدة في ال CSS */
        @media print {
            .no-print, 
            .action-buttons, 
            .contact-info { /* إضافة هذه الفئة */
                display: none !important;
            }
            
            .order-container {
                box-shadow: none;
                border: 1px solid #ddd;
            }
        }
    </style>
</head>
<body>
    <div class="order-container">
        <!-- ... باقي محتوى الفاتورة ... -->
        <div class="invoice-header">
            <center>
            <?php if (!empty($settings['logo_path'])): ?>
                <img src="../<?= htmlspecialchars($settings['logo_path']) ?>" class="logo" alt="شعار المتجر">
            <?php endif; ?>
            <h1><?= htmlspecialchars($settings['site_name']) ?></h1>
            <div class="invoice-info">
                <div>رقم الفاتورة: <?= $order_id ?></div>
                <div>تاريخ الإصدار: <?= date('Y-m-d H:i') ?></div>
            </div>
        </div>
            </center>
        <div class="customer-info">
            <h3>معلومات العميل:</h3>
            <p>الاسم: <?= htmlspecialchars($order['customer_name']) ?></p>
            <p>الهاتف: <?= htmlspecialchars($order['phone']) ?></p>
            <p>العنوان: <?= htmlspecialchars($order['shipping_address']) ?></p>
        </div>

        <h3><i class="fas fa-boxes"></i> المنتجات المطلوبة</h3>
        <table class="order-table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>الصورة</th>
                    <th>المنتج</th>
                    <th>السعر</th>
                    <th>الكمية</th>
                    <th>المجموع</th>
                </tr>
            </thead>
            <tbody>
                <?php $total = 0; ?>
                <?php foreach ($items as $index => $item): ?>
                    <?php $item_total = $item['price'] * $item['quantity']; ?>
                    <?php $total += $item_total; ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td>
                            <img src="../uploads/img/<?= $item['image'] ?? 'default.jpg' ?>" 
                                 class="product-image"
                                 onerror="this.src='../images/default-product.jpg'">
                        </td>
                        <td><?= htmlspecialchars($item['name'] ?? 'منتج محذوف') ?></td>
                        <td><?= number_format($item['price'], 2) ?> د.ل</td>
                        <td><?= $item['quantity'] ?></td>
                        <td><?= number_format($item_total, 2) ?> د.ل</td>
                    </tr>
                <?php endforeach; ?>
                <tr class="total-row">
                    <td colspan="5">المجموع الكلي</td>
                    <td><?= number_format($total, 2) ?> د.ل</td>
                </tr>
            </tbody>
        </table>

        <!-- التعديل على قسم الاتصال الأول -->
        <div class="contact-info no-print"> <!-- إضافة كلاس no-print هنا -->
            <form method="post">
                <button type="submit" name="send_invoice" class="whatsapp-btn">
                    <i class="fab fa-whatsapp"></i> إرسال الفاتورة عبر واتساب
                </button>
            </form>
        </div>

        <!-- التعديل على قسم الاتصال الثاني -->
        <?php if(!empty($order['phone'])): ?>
        <div class="contact-info no-print"> <!-- إضافة كلاس no-print هنا -->
            <div class="contact-item">
                <i class="fas fa-phone"></i>
                <span>اتصال هاتفي: <?= $order['phone'] ?></span>
                <a href="tel:<?= $order['phone'] ?>" class="btn">اتصال</a>
            </div>
            <div class="contact-item">
                <i class="fab fa-whatsapp"></i>
                <span>مراسلة عبر واتساب:</span>
                <a href="https://wa.me/<?= format_whatsapp_number($order['phone']) ?>" 
                    class="whatsapp-btn"
                    target="_blank">
                    <i class="fab fa-whatsapp"></i> إرسال رسالة
                </a>
            </div>
        </div>
        <?php endif; ?>
    </div>


    <div class="action-buttons">
            <a href="admin_orders1.php" class="btn btn-back">
                <i class="fas fa-arrow-right"></i> العودة للقائمة
            </a>
            <div class="button-group">
                <button onclick="window.print()" class="btn btn-print">
                    <i class="fas fa-print"></i> طباعة الفاتورة
                </button>
                <a href="admin_edit_order.php?id=<?= $order_id ?>" class="btn btn-edit">
                    <i class="fas fa-edit"></i> تعديل الطلب
                </a>
            </div>
        </div>





</body>
</html>




<!-- باقي محتوى الصفحة -->
