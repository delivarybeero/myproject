<?php
session_start();
include("../include/connection.php");

// التحقق من الجلسة
if(!isset($_SESSION['EMAIL'])){
    header("Location: admin.php");
    exit();
}

// إنشاء مجلد التحميلات إذا لم يكن موجوداً
$upload_dir = "../uploads/img/";
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// معالجة البيانات المرسلة
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['proadd'])) {
    // تنظيف المدخلات
    $proname = mysqli_real_escape_string($conn, $_POST['name']);
    $proprice = floatval($_POST['price']);
    $prodescrip = mysqli_real_escape_string($conn, $_POST['description']);
    $prosize = mysqli_real_escape_string($conn, $_POST['prosize']);
    $quantity = intval($_POST['quantity']);

    // معالجة الصورة
    $imageName = basename($_FILES['image']['name']);
    $imageExtension = strtolower(pathinfo($imageName, PATHINFO_EXTENSION));
    $newImageName = uniqid() . '.' . $imageExtension; // اسم فريد للصورة
    $target_path = $upload_dir . $newImageName;

    // التحقق من نوع الملف
    $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
    if(!in_array($imageExtension, $allowed_types)) {
        die("<script>alert('الملفات المسموح بها: JPG, JPEG, PNG, GIF');</script>");
    }

    // تحميل الصورة
   
    if (move_uploaded_file($imageTmp, "../uploads/img/" . $proimg)) {

    //if(move_uploaded_file($_FILES['image']['tmp_name'], $target_path)) {
        // إدخال البيانات في قاعدة البيانات مع المسار الصحيح
        $stmt = $conn->prepare("INSERT INTO products 
            (name, image, price, description, prosize, quantity)
            VALUES (?, ?, ?, ?, ?, ?)");
        
        // المسار الذي سيتم تخزينه في قاعدة البيانات
        $db_image_path = "../uploads/img/" . $newImageName;
        
        $stmt->bind_param("ssdssi", 
            $proname,
            $db_image_path,
            $proprice,
            $prodescrip,
            $prosize,
            $quantity);

        if($stmt->execute()){
            echo '<script>alert("تمت الإضافة بنجاح");</script>';
        } else {
            echo '<script>alert("خطأ في قاعدة البيانات: ' . $stmt->error . '");</script>';
        }
        $stmt->close();
    } else {
        echo '<script>alert("خطأ في تحميل الصورة");</script>';
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إضافة منتج جديد</title>
    <style>
        body {font-family: Arial, sans-serif; background: #f0f0f0;}
        .container {max-width: 800px; margin: 20px auto; padding: 20px; background: white; border-radius: 8px;}
        .form-group {margin-bottom: 15px;}
        label {display: block; margin-bottom: 5px; font-weight: bold;}
        input, select, textarea {width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 4px;}
        .button {background: #4CAF50; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;}
        .button:hover {background: #45a049;}
     </style>
</head>
<body>
    <div class="container">
        <h1>إضافة منتج جديد</h1>
        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label>اسم المنتج:</label>
                <input type="text" name="name" required>
            </div>

            <div class="form-group">
                <label>السعر:</label>
                <input type="number" name="price" step="0.01" required>
            </div>

            <div class="form-group">
                <label>الوصف:</label>
                <textarea name="description" required></textarea>
            </div>

            <div class="form-group">
                <label>الحجم/الوزن:</label>
                <input type="text" name="prosize" required>
            </div>

            <div class="form-group">
                <label>الكمية:</label>
                <input type="number" name="quantity" required>
            </div>
           

            <div class="form-group">
                <label>صورة المنتج:</label>
                <input type="file" name="image" accept="image/*" required>
            </div>

            <button type="submit" name="proadd" class="button">إضافة المنتج</button>
            <a href="admianpanel.php" class="button">العودة للوحة التحكم</a>
                </form>
    </div>
</body>
</html>